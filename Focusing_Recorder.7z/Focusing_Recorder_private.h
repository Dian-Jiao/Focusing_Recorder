/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef FOCUSING_RECORDER_PRIVATE_H
#define FOCUSING_RECORDER_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.2.0.0"
#define VER_MAJOR	1
#define VER_MINOR	2
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"yhcz171726"
#define FILE_VERSION	"1.2.0.0"
#define FILE_DESCRIPTION	"Focusing Recorder"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"Copyright (C) 2018-2020 Dian_Jiao, All Rights Reserved."
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	""
#define PRODUCT_VERSION	"1.2.0.0"

#endif /*FOCUSING_RECORDER_PRIVATE_H*/
